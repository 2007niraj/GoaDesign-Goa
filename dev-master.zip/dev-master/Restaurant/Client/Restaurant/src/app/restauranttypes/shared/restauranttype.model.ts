export class Restauranttype {
  ID : string
  Name : string
}
